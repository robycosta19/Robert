package com.example.bluetooth_is.models

data class SensorData(
    val timestamp: String,
    val pulse: Int,
    val temperature: Float,
    val humidity: Int,
    val ecgValue: Float
)
