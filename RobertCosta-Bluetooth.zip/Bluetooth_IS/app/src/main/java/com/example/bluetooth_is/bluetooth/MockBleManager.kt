package com.example.bluetooth_is.bluetooth

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.bluetooth_is.models.SensorData
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class MockBleManager {

    private var listener: BleDataListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false

    fun setListener(listener: BleDataListener) {
        this.listener = listener
    }

    fun startMockData() {
        isRunning = true

        handler.postDelayed({
            listener?.onDeviceFound("SmartLink-ESP32", "AA:BB:CC:DD:EE:FF")
        }, 2000)

        handler.postDelayed({
            listener?.onConnectionStateChanged(true, "SmartLink-ESP32")
        }, 4000)

        val dataRunnable = object : Runnable {
            override fun run() {
                if (!isRunning) return

                val data = SensorData(
                    timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
                    pulse = Random.nextInt(60, 120),
                    temperature = 36.0f + Random.nextFloat() * 2.5f,
                    humidity = Random.nextInt(30, 70),
                    ecgValue = Random.nextFloat() * 300
                )

                Log.d("MockBLE", "Date simulate: puls=${data.pulse}, temp=${data.temperature}")
                listener?.onSensorDataReceived(data)

                handler.postDelayed(this, 10_000)
            }
        }
        handler.postDelayed(dataRunnable, 5000)

        Log.d("MockBLE", "Mock BLE pornit — date simulate la fiecare 10s")
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
    }
}
