package com.example.bluetooth_is.bluetooth

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat

class BleManager(private val context: Context) {

    companion object {
        private const val TAG = "BleManager"
    }

    private val bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var bleScanner: BluetoothLeScanner? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var listener: BleDataListener? = null

    private var isScanning = false
    private var isConnected = false

    private val handler = Handler(Looper.getMainLooper())

    fun setListener(listener: BleDataListener) {
        this.listener = listener
    }

    fun hasPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) ==
                    PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                    PackageManager.PERMISSION_GRANTED
        }
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
    }

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    fun startScan() {
        if (!hasPermissions()) {
            listener?.onError("Lipsesc permisiunile Bluetooth. Mergi la Settings → Permissions.")
            return
        }
        if (!isBluetoothEnabled()) {
            listener?.onError("Bluetooth-ul e oprit. Pornește-l din setări.")
            return
        }
        if (isScanning) {
            Log.d(TAG, "Deja scanează...")
            return
        }

        bleScanner = bluetoothAdapter?.bluetoothLeScanner
        if (bleScanner == null) {
            listener?.onError("Scanner-ul BLE nu e disponibil")
            return
        }

        isScanning = true
        Log.d(TAG, "Scanare pornită — caut dispozitive BLE...")

        handler.postDelayed({
            stopScan()
        }, BleConstants.SCAN_TIMEOUT_MS)

        try {
            bleScanner?.startScan(scanCallback)
        } catch (e: SecurityException) {
            listener?.onError("Permisiune BLE refuzată: ${e.message}")
        }
    }

    fun stopScan() {
        if (!isScanning) return
        isScanning = false
        try {
            bleScanner?.stopScan(scanCallback)
        } catch (e: SecurityException) {
            Log.e(TAG, "Eroare oprire scan: ${e.message}")
        }
        Log.d(TAG, "Scanare oprită")
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            try {
                val device = result.device
                val name = device.name ?: return

                Log.d(TAG, "Dispozitiv găsit: $name (${device.address})")
                listener?.onDeviceFound(name, device.address)

                if (name == BleConstants.DEVICE_NAME) {
                    Log.d(TAG, "ESP32 SmartLink găsit! Mă conectez...")
                    stopScan()
                    connectToDevice(device)
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException în scanCallback: ${e.message}")
            }
        }

        override fun onScanFailed(errorCode: Int) {
            isScanning = false
            listener?.onError("Scanare eșuată: $errorCode")
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        try {
            bluetoothGatt = device.connectGatt(context, false, gattCallback)
            Log.d(TAG, "Conectare inițiată la ${device.address}...")
        } catch (e: SecurityException) {
            listener?.onError("Permisiune refuzată la conectare: ${e.message}")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            try {
                when (newState) {
                    BluetoothGatt.STATE_CONNECTED -> {
                        isConnected = true
                        Log.d(TAG, "CONECTAT la ESP32!")
                        listener?.onConnectionStateChanged(true, gatt.device.name)
                        gatt.discoverServices()
                    }
                    BluetoothGatt.STATE_DISCONNECTED -> {
                        isConnected = false
                        Log.d(TAG, "DECONECTAT de la ESP32")
                        listener?.onConnectionStateChanged(false, null)
                        bluetoothGatt?.close()
                        bluetoothGatt = null
                    }
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException la connection state: ${e.message}")
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener?.onError("Eroare la descoperirea serviciilor: status $status")
                return
            }

            val service = gatt.getService(BleConstants.SERVICE_UUID)
            if (service == null) {
                listener?.onError("Serviciul SmartLink nu a fost găsit pe ESP32.")
                return
            }

            val sensorChar = service.getCharacteristic(BleConstants.SENSOR_DATA_UUID)
            if (sensorChar != null) {
                enableNotifications(gatt, sensorChar)
            }

            val ecgChar = service.getCharacteristic(BleConstants.ECG_DATA_UUID)
            if (ecgChar != null) {
                handler.postDelayed({
                    enableNotifications(gatt, ecgChar)
                }, 500)
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            val rawString = String(value, Charsets.UTF_8)
            when (characteristic.uuid) {
                BleConstants.SENSOR_DATA_UUID -> {
                    val sensorData = BleDataParser.parseJsonString(rawString)
                        ?: BleDataParser.parseCsvString(rawString)
                        ?: BleDataParser.parseBytes(value)

                    if (sensorData != null) {
                        handler.post { listener?.onSensorDataReceived(sensorData) }
                    }
                }
                BleConstants.ECG_DATA_UUID -> {
                    val ecgValues = BleDataParser.parseEcgBurst(rawString)
                    if (ecgValues != null) {
                        handler.post { listener?.onEcgDataReceived(ecgValues) }
                    }
                }
            }
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            characteristic.value?.let { onCharacteristicChanged(gatt, characteristic, it) }
        }
    }

    private fun enableNotifications(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
        try {
            gatt.setCharacteristicNotification(characteristic, true)
            val descriptor = characteristic.getDescriptor(BleConstants.CCCD_UUID)
            if (descriptor != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                } else {
                    @Suppress("DEPRECATION")
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    gatt.writeDescriptor(descriptor)
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException la activare notificări: ${e.message}")
        }
    }

    fun disconnect() {
        try {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
        } catch (e: SecurityException) {
            Log.e(TAG, "Eroare deconectare: ${e.message}")
        }
        bluetoothGatt = null
        isConnected = false
    }

    fun cleanup() {
        stopScan()
        disconnect()
        handler.removeCallbacksAndMessages(null)
    }
}
