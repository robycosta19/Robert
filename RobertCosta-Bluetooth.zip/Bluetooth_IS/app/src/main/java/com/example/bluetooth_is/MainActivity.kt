package com.example.bluetooth_is

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.bluetooth_is.bluetooth.BleDataListener
import com.example.bluetooth_is.bluetooth.BleManager
import com.example.bluetooth_is.models.SensorData

class MainActivity : AppCompatActivity() {

    private lateinit var bleManager: BleManager
    private lateinit var tvStatus: TextView
    private lateinit var tvPulse: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvHumidity: TextView
    private lateinit var tvEcg: TextView
    private lateinit var tvTime: TextView
    private lateinit var btnScan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvPulse = findViewById(R.id.tvPulse)
        tvTemp = findViewById(R.id.tvTemp)
        tvHumidity = findViewById(R.id.tvHumidity)
        tvEcg = findViewById(R.id.tvEcg)
        tvTime = findViewById(R.id.tvTime)
        btnScan = findViewById(R.id.btnScan)

        bleManager = BleManager(this)

        bleManager.setListener(object : BleDataListener {
            override fun onSensorDataReceived(data: SensorData) {
                runOnUiThread {
                    tvPulse.text = "Puls: ${data.pulse}"
                    tvTemp.text = "Temperatură: ${data.temperature} °C"
                    tvHumidity.text = "Umiditate: ${data.humidity} %"
                    tvEcg.text = "ECG: ${data.ecgValue}"
                    tvTime.text = "Ultima actualizare: ${data.timestamp}"
                }
            }

            override fun onEcgDataReceived(ecgValues: FloatArray) {
                Log.d("MainActivity", "ECG Received: ${ecgValues.size} values")
            }

            override fun onConnectionStateChanged(connected: Boolean, deviceName: String?) {
                runOnUiThread {
                    if (connected) {
                        tvStatus.text = "Status: Conectat la $deviceName"
                        btnScan.isEnabled = false
                    } else {
                        tvStatus.text = "Status: Deconectat"
                        btnScan.isEnabled = true
                    }
                }
            }

            override fun onDeviceFound(name: String, address: String) {
                Log.d("MainActivity", "Found: $name at $address")
            }

            override fun onError(message: String) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        })

        btnScan.setOnClickListener {
            if (bleManager.hasPermissions()) {
                bleManager.startScan()
            } else {
                requestBlePermissions()
            }
        }
    }

    private fun requestBlePermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 200)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                bleManager.startScan()
            } else {
                Toast.makeText(this, "Permisiuni refuzate", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bleManager.cleanup()
    }
}
