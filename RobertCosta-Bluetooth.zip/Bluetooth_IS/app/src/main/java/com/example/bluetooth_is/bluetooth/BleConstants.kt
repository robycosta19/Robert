package com.example.bluetooth_is.bluetooth

import java.util.UUID

object BleConstants {

    // Numele ESP32-ului nostru — îl vezi când scanezi
    const val DEVICE_NAME = "SmartLink-ESP32"

    // UUID Serviciu principal
    val SERVICE_UUID: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")

    // UUID Caracteristică date senzori
    val SENSOR_DATA_UUID: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")

    // UUID Caracteristică ECG
    val ECG_DATA_UUID: UUID = UUID.fromString("0000ffe2-0000-1000-8000-00805f9b34fb")

    // UUID Descriptor pentru notificări BLE
    val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    // Timeout-uri
    const val SCAN_TIMEOUT_MS = 15_000L
    const val CONNECTION_TIMEOUT_MS = 10_000L
}
