package com.example.bluetooth_is.bluetooth

import android.util.Log
import com.example.bluetooth_is.models.SensorData
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

object BleDataParser {

    private const val TAG = "BleDataParser"

    fun parseJsonString(raw: String): SensorData? {
        return try {
            val json = JSONObject(raw)
            SensorData(
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
                pulse = json.optInt("pulse", 0),
                temperature = json.optDouble("temp", 0.0).toFloat(),
                humidity = json.optInt("hum", 0),
                ecgValue = json.optDouble("ecg", 0.0).toFloat()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Eroare parsare JSON: ${e.message} — raw: $raw")
            null
        }
    }

    fun parseCsvString(raw: String): SensorData? {
        return try {
            val parts = raw.trim().split(",")
            if (parts.size < 4) {
                Log.e(TAG, "CSV incomplet: $raw")
                return null
            }
            SensorData(
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
                pulse = parts[0].trim().toInt(),
                temperature = parts[1].trim().toFloat(),
                humidity = parts[2].trim().toInt(),
                ecgValue = parts[3].trim().toFloat()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Eroare parsare CSV: ${e.message} — raw: $raw")
            null
        }
    }

    fun parseBytes(bytes: ByteArray): SensorData? {
        return try {
            if (bytes.size < 8) {
                Log.e(TAG, "Bytes insuficienți: ${bytes.size}")
                return null
            }
            val pulse = ((bytes[0].toInt() and 0xFF) shl 8) or (bytes[1].toInt() and 0xFF)
            val tempRaw = ((bytes[2].toInt() and 0xFF) shl 8) or (bytes[3].toInt() and 0xFF)
            val humidity = ((bytes[4].toInt() and 0xFF) shl 8) or (bytes[5].toInt() and 0xFF)
            val ecgRaw = ((bytes[6].toInt() and 0xFF) shl 8) or (bytes[7].toInt() and 0xFF)

            SensorData(
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
                pulse = pulse,
                temperature = tempRaw / 10f,
                humidity = humidity,
                ecgValue = ecgRaw.toFloat()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Eroare parsare bytes: ${e.message}")
            null
        }
    }

    fun parseEcgBurst(raw: String): FloatArray? {
        return try {
            raw.trim().split(",").map { it.trim().toFloat() }.toFloatArray()
        } catch (e: Exception) {
            Log.e(TAG, "Eroare parsare ECG burst: ${e.message}")
            null
        }
    }
}
