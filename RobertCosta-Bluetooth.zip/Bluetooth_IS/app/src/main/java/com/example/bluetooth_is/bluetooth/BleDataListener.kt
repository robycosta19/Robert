package com.example.bluetooth_is.bluetooth

import com.example.bluetooth_is.models.SensorData

interface BleDataListener {
    fun onSensorDataReceived(data: SensorData)
    fun onEcgDataReceived(ecgValues: FloatArray)
    fun onConnectionStateChanged(connected: Boolean, deviceName: String?)
    fun onDeviceFound(name: String, address: String)
    fun onError(message: String)
}
